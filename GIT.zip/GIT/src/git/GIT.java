package git;

import java.util.Scanner;

public class GIT {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		//Información de lo que hace el programa
		System.out.println("Este programa suma dos números introducidos por el usuario.");
		
		//Pido los datos pertinentes
		System.out.print("Introduce el primer número: ");
		int primerNumero = Integer.parseInt(scanner.next());
		System.out.print("Introduce el segundo número: ");
		int segundoNumero = Integer.parseInt(scanner.next());

		//Operación
		int resultado = primerNumero + segundoNumero;
		System.out.println("El resultado es: " + resultado);
		
		scanner.close();
	}
}

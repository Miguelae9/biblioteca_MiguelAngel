package git_2;

import java.util.Scanner;

public class GIT_2 {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		//Información de lo que hace el programa
		System.out.println("Este programa te dice si lo números introducidos por el usuario son par.");
		
		//Pido los datos pertinentes
		System.out.print("Introduce el número: ");
		int numero1 = Integer.parseInt(scanner.next());

		//Operación
		int resultado = numero1 % 2;
		if (resultado == 0) {
		System.out.println("El resultado es par");
			}else if (resultado != 0){
			System.out.println("El resultado es impar");
		}
		
		scanner.close();
	}
}
